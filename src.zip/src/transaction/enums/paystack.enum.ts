export enum PaystackCurrency {
    NGN = "NGN"
}