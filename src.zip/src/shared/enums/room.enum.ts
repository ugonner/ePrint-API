export enum RoomAidType {
    INTERPRETER = "Interpreter"
}