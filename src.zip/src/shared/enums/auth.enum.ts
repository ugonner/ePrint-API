export enum AuthStatus {
    ACTIVE = "Active",
    INACTIVE = "Inactive"
}

export enum UserType {
    USER = "User",
    GUEST = "Guest"
}