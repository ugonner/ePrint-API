
export enum ServiceType {
  APP_PROFILE = "App_Profile",
  BOOKING = "Booking",
}