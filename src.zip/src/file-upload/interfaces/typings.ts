export interface IAttachment {
    attachmentType: "video" | "image" | "audio" | "document";
    attachmentUrl: string;
}