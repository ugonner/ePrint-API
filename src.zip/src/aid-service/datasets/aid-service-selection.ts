export const AidServiceSelectFields: string[] = [
    "aidService.id",
    "aidService.name",
    "aidService.description",
    "aidService.avatar",
    "aidService.createdAt",
    "aidService.serviceRate",
    "tags.name"
];
