export enum AddOrRemoveAction {
    ADD = "Add",
    REMOVE = "Remove"
}