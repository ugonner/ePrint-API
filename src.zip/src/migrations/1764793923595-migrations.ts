import { MigrationInterface, QueryRunner } from "typeorm";

export class Migrations1764793923595 implements MigrationInterface {
    name = 'Migrations1764793923595'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            CREATE TABLE \`role\` (
                \`id\` int NOT NULL AUTO_INCREMENT,
                \`name\` varchar(255) NOT NULL,
                \`description\` varchar(255) NULL,
                \`permissions\` json NULL,
                \`createdAt\` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
                \`updatedAt\` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
                \`isDeleted\` tinyint NOT NULL DEFAULT 0,
                UNIQUE INDEX \`IDX_ae4578dcaed5adff96595e6166\` (\`name\`),
                PRIMARY KEY (\`id\`)
            ) ENGINE = InnoDB
        `);
        await queryRunner.query(`
            CREATE TABLE \`auth\` (
                \`id\` int NOT NULL AUTO_INCREMENT,
                \`email\` varchar(255) NULL,
                \`phoneNumber\` varchar(255) NULL,
                \`password\` varchar(255) NOT NULL,
                \`userType\` varchar(255) NOT NULL DEFAULT 'Guest',
                \`status\` varchar(255) NOT NULL DEFAULT 'Inactive',
                \`userId\` varchar(255) NOT NULL,
                \`firstName\` varchar(255) NULL,
                \`lastName\` varchar(255) NULL,
                \`otp\` int NULL,
                \`otpTime\` datetime NULL,
                \`isVerified\` tinyint NOT NULL DEFAULT 0,
                \`createdAt\` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
                \`updatedAt\` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
                \`isDeleted\` tinyint NOT NULL DEFAULT 0,
                \`roleId\` int NULL,
                \`profileId\` int NULL,
                UNIQUE INDEX \`IDX_373ead146f110f04dad6084815\` (\`userId\`),
                UNIQUE INDEX \`REL_ca49e738c1e64b0c839cae30d4\` (\`profileId\`),
                PRIMARY KEY (\`id\`)
            ) ENGINE = InnoDB
        `);
        await queryRunner.query(`
            CREATE TABLE \`tag\` (
                \`id\` int NOT NULL AUTO_INCREMENT,
                \`name\` varchar(255) NOT NULL,
                \`createdAt\` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
                \`updatedAt\` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
                \`isDeleted\` tinyint NOT NULL DEFAULT 0,
                PRIMARY KEY (\`id\`)
            ) ENGINE = InnoDB
        `);
        await queryRunner.query(`
            CREATE TABLE \`aid_service_tag\` (
                \`id\` int NOT NULL AUTO_INCREMENT,
                \`createdAt\` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
                \`updatedAt\` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
                \`isDeleted\` tinyint NOT NULL DEFAULT 0,
                \`tagId\` int NULL,
                \`aidServiceId\` int NULL,
                PRIMARY KEY (\`id\`)
            ) ENGINE = InnoDB
        `);
        await queryRunner.query(`
            CREATE TABLE \`profile_cluster\` (
                \`id\` int NOT NULL AUTO_INCREMENT,
                \`createdAt\` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
                \`updatedAt\` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
                \`isDeleted\` tinyint NOT NULL DEFAULT 0,
                \`clusterId\` int NULL,
                \`profileId\` int NULL,
                PRIMARY KEY (\`id\`)
            ) ENGINE = InnoDB
        `);
        await queryRunner.query(`
            CREATE TABLE \`cluster\` (
                \`id\` int NOT NULL AUTO_INCREMENT,
                \`name\` varchar(255) NOT NULL,
                \`description\` varchar(255) NULL,
                \`createdAt\` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
                \`updatedAt\` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
                \`isDeleted\` tinyint NOT NULL DEFAULT 0,
                PRIMARY KEY (\`id\`)
            ) ENGINE = InnoDB
        `);
        await queryRunner.query(`
            CREATE TABLE \`aid_service_cluster\` (
                \`id\` int NOT NULL AUTO_INCREMENT,
                \`createdAt\` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
                \`updatedAt\` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
                \`isDeleted\` tinyint NOT NULL DEFAULT 0,
                \`clusterId\` int NULL,
                \`aidServiceId\` int NULL,
                PRIMARY KEY (\`id\`)
            ) ENGINE = InnoDB
        `);
        await queryRunner.query(`
            CREATE TABLE \`aid_service\` (
                \`id\` int NOT NULL AUTO_INCREMENT,
                \`name\` varchar(255) NOT NULL,
                \`description\` varchar(255) NULL,
                \`avatar\` varchar(255) NULL,
                \`serviceRate\` int NULL DEFAULT '0',
                \`noOfBookings\` int NULL DEFAULT '0',
                \`createdAt\` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
                \`isDeleted\` tinyint NOT NULL DEFAULT 0,
                \`profileId\` int NULL,
                PRIMARY KEY (\`id\`)
            ) ENGINE = InnoDB
        `);
        await queryRunner.query(`
            CREATE TABLE \`payment_transaction\` (
                \`id\` varchar(36) NOT NULL,
                \`paymentRef\` varchar(255) NULL,
                \`paymentMethod\` varchar(255) NOT NULL,
                \`paymentStatus\` varchar(255) NOT NULL,
                \`paymentPurpose\` varchar(255) NOT NULL,
                \`amount\` int NOT NULL,
                \`createdAt\` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
                \`updatedAt\` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
                \`bookingId\` int NULL,
                \`profileId\` int NULL,
                UNIQUE INDEX \`REL_a0df4573f2a0c4d351fea2c598\` (\`bookingId\`),
                PRIMARY KEY (\`id\`)
            ) ENGINE = InnoDB
        `);
        await queryRunner.query(`
            CREATE TABLE \`aid_service_profile\` (
                \`id\` int NOT NULL AUTO_INCREMENT,
                \`employeeId\` varchar(255) NULL,
                \`noOfServicesCompleted\` int NOT NULL DEFAULT '0',
                \`contactPhoneNumber\` varchar(255) NULL,
                \`socialMediaLinks\` json NULL,
                \`locationAddress\` json NULL,
                \`verificationComment\` varchar(255) NULL,
                \`averageRating\` float NOT NULL DEFAULT '0',
                \`noOfRatings\` float NOT NULL DEFAULT '0',
                \`createdAt\` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
                \`updatedAt\` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
                \`isDeleted\` tinyint NOT NULL DEFAULT 0,
                PRIMARY KEY (\`id\`)
            ) ENGINE = InnoDB
        `);
        await queryRunner.query(`
            CREATE TABLE \`booking\` (
                \`id\` int NOT NULL AUTO_INCREMENT,
                \`compositeBookingId\` varchar(255) NOT NULL,
                \`bookingStatus\` varchar(255) NOT NULL DEFAULT 'Pending',
                \`bookingStatusNote\` varchar(255) NULL,
                \`paymentStatus\` varchar(255) NOT NULL DEFAULT 'Not Paid',
                \`totalAmount\` int NOT NULL DEFAULT '0',
                \`bookingNote\` varchar(255) NULL,
                \`locationAddress\` json NULL,
                \`startDate\` varchar(255) NOT NULL,
                \`endDate\` varchar(255) NOT NULL,
                \`confirmedByProvider\` tinyint NOT NULL DEFAULT 0,
                \`confirmedByUser\` tinyint NOT NULL DEFAULT 0,
                \`rating\` float NOT NULL DEFAULT '0',
                \`review\` varchar(255) NULL,
                \`isMatched\` tinyint NOT NULL DEFAULT 0,
                \`descriptionMedia\` json NULL,
                \`rawMediaFiles\` json NULL,
                \`contactPhoneNumber\` varchar(255) NULL,
                \`deliveryType\` varchar(255) NOT NULL DEFAULT 'Door Step',
                \`processedMediaFiles\` json NULL,
                \`createdAt\` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
                \`updatedAt\` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
                \`isDeleted\` tinyint NOT NULL DEFAULT 0,
                \`aidServiceId\` int NULL,
                \`aidServiceProfileId\` int NULL,
                \`profileId\` int NULL,
                PRIMARY KEY (\`id\`)
            ) ENGINE = InnoDB
        `);
        await queryRunner.query(`
            CREATE TABLE \`profile\` (
                \`id\` int NOT NULL AUTO_INCREMENT,
                \`userId\` varchar(255) NOT NULL,
                \`email\` varchar(255) NULL,
                \`firstName\` varchar(255) NULL,
                \`lastName\` varchar(255) NULL,
                \`avatar\` varchar(255) NULL,
                \`gender\` varchar(255) NULL,
                \`phoneNumber\` varchar(255) NULL,
                \`disabilityType\` varchar(255) NULL,
                \`createdAt\` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
                \`updatedAt\` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
                \`isDeleted\` tinyint NOT NULL DEFAULT 0,
                \`walletId\` int NULL,
                \`aidServiceProfileId\` int NULL,
                UNIQUE INDEX \`REL_d307cd0f00be8c8efcc831102b\` (\`walletId\`),
                UNIQUE INDEX \`REL_2e55eaf05dc6707d1541e7bebf\` (\`aidServiceProfileId\`),
                PRIMARY KEY (\`id\`)
            ) ENGINE = InnoDB
        `);
        await queryRunner.query(`
            CREATE TABLE \`profile_wallet\` (
                \`id\` int NOT NULL AUTO_INCREMENT,
                \`fundedBalance\` decimal(12, 2) NOT NULL DEFAULT '0.00',
                \`earnedBalance\` decimal(12, 2) NOT NULL DEFAULT '0.00',
                \`pendingBalance\` decimal(12, 2) NOT NULL DEFAULT '0.00',
                \`createdAt\` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
                \`updatedAt\` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
                \`isDeleted\` tinyint NOT NULL DEFAULT 0,
                PRIMARY KEY (\`id\`)
            ) ENGINE = InnoDB
        `);
        await queryRunner.query(`
            CREATE TABLE \`review_and_rating\` (
                \`id\` int NOT NULL AUTO_INCREMENT,
                \`rating\` int NOT NULL,
                \`review\` varchar(255) NULL,
                \`serviceType\` varchar(255) NOT NULL,
                \`serviceTypeEntityId\` int NOT NULL,
                \`profileId\` int NOT NULL,
                \`createdAt\` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
                \`isDeleted\` tinyint NOT NULL DEFAULT 0,
                PRIMARY KEY (\`id\`)
            ) ENGINE = InnoDB
        `);
        await queryRunner.query(`
            CREATE TABLE \`report\` (
                \`id\` int NOT NULL AUTO_INCREMENT,
                \`rating\` int NOT NULL,
                \`review\` varchar(255) NULL,
                \`serviceType\` varchar(255) NOT NULL,
                \`serviceTypeEntityId\` int NOT NULL,
                \`profileId\` int NOT NULL,
                \`isResolved\` tinyint NOT NULL DEFAULT 0,
                \`resolvedById\` int NULL,
                \`comment\` varchar(255) NULL,
                \`createdAt\` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
                \`isDeleted\` tinyint NOT NULL DEFAULT 0,
                \`profile_id\` int NULL,
                \`entityOwnerId\` int NULL,
                PRIMARY KEY (\`id\`)
            ) ENGINE = InnoDB
        `);
        await queryRunner.query(`
            CREATE TABLE \`report_comment\` (
                \`id\` int NOT NULL AUTO_INCREMENT,
                \`comment\` varchar(255) NOT NULL,
                \`createdAt\` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
                \`updatedAt\` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
                \`isDeleted\` tinyint NOT NULL DEFAULT 0,
                \`profileId\` int NULL,
                \`reportId\` int NULL,
                PRIMARY KEY (\`id\`)
            ) ENGINE = InnoDB
        `);
        await queryRunner.query(`
            CREATE TABLE \`notification\` (
                \`id\` int NOT NULL AUTO_INCREMENT,
                \`title\` varchar(255) NOT NULL,
                \`description\` varchar(255) NULL,
                \`data\` json NULL,
                \`avatar\` varchar(255) NULL,
                \`notificationEventType\` varchar(255) NOT NULL,
                \`context\` varchar(255) NOT NULL,
                \`contextEntityId\` int NULL,
                \`viewed\` tinyint NOT NULL DEFAULT 0,
                \`createdAt\` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
                \`updatedAt\` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
                \`isDeleted\` tinyint NOT NULL DEFAULT 0,
                \`creatorId\` int NULL,
                \`receiverId\` int NULL,
                PRIMARY KEY (\`id\`)
            ) ENGINE = InnoDB
        `);
        await queryRunner.query(`
            ALTER TABLE \`auth\`
            ADD CONSTRAINT \`FK_b368cb67ee97687c9fdc9a04153\` FOREIGN KEY (\`roleId\`) REFERENCES \`role\`(\`id\`) ON DELETE NO ACTION ON UPDATE NO ACTION
        `);
        await queryRunner.query(`
            ALTER TABLE \`auth\`
            ADD CONSTRAINT \`FK_ca49e738c1e64b0c839cae30d4e\` FOREIGN KEY (\`profileId\`) REFERENCES \`profile\`(\`id\`) ON DELETE CASCADE ON UPDATE NO ACTION
        `);
        await queryRunner.query(`
            ALTER TABLE \`aid_service_tag\`
            ADD CONSTRAINT \`FK_c8e96e96979cd2bf2afd75e91d2\` FOREIGN KEY (\`tagId\`) REFERENCES \`tag\`(\`id\`) ON DELETE NO ACTION ON UPDATE NO ACTION
        `);
        await queryRunner.query(`
            ALTER TABLE \`aid_service_tag\`
            ADD CONSTRAINT \`FK_81a7eb4e5de9ec5fc0f0d548b37\` FOREIGN KEY (\`aidServiceId\`) REFERENCES \`aid_service\`(\`id\`) ON DELETE NO ACTION ON UPDATE NO ACTION
        `);
        await queryRunner.query(`
            ALTER TABLE \`profile_cluster\`
            ADD CONSTRAINT \`FK_d97aad3ecb862bab0f395747f3c\` FOREIGN KEY (\`clusterId\`) REFERENCES \`cluster\`(\`id\`) ON DELETE NO ACTION ON UPDATE NO ACTION
        `);
        await queryRunner.query(`
            ALTER TABLE \`profile_cluster\`
            ADD CONSTRAINT \`FK_b1e2c1cc3a940ed52b1ea664477\` FOREIGN KEY (\`profileId\`) REFERENCES \`profile\`(\`id\`) ON DELETE NO ACTION ON UPDATE NO ACTION
        `);
        await queryRunner.query(`
            ALTER TABLE \`aid_service_cluster\`
            ADD CONSTRAINT \`FK_425b0a6f642f091a9a49975d8f0\` FOREIGN KEY (\`clusterId\`) REFERENCES \`cluster\`(\`id\`) ON DELETE NO ACTION ON UPDATE NO ACTION
        `);
        await queryRunner.query(`
            ALTER TABLE \`aid_service_cluster\`
            ADD CONSTRAINT \`FK_bb1c821ee7b4c78c4ca909d657d\` FOREIGN KEY (\`aidServiceId\`) REFERENCES \`aid_service\`(\`id\`) ON DELETE NO ACTION ON UPDATE NO ACTION
        `);
        await queryRunner.query(`
            ALTER TABLE \`aid_service\`
            ADD CONSTRAINT \`FK_bf0c29f8bba419447fde8fbed43\` FOREIGN KEY (\`profileId\`) REFERENCES \`profile\`(\`id\`) ON DELETE NO ACTION ON UPDATE NO ACTION
        `);
        await queryRunner.query(`
            ALTER TABLE \`payment_transaction\`
            ADD CONSTRAINT \`FK_a0df4573f2a0c4d351fea2c5986\` FOREIGN KEY (\`bookingId\`) REFERENCES \`booking\`(\`id\`) ON DELETE NO ACTION ON UPDATE NO ACTION
        `);
        await queryRunner.query(`
            ALTER TABLE \`payment_transaction\`
            ADD CONSTRAINT \`FK_e25ef1ea9f15b50d4aa150731a1\` FOREIGN KEY (\`profileId\`) REFERENCES \`profile\`(\`id\`) ON DELETE NO ACTION ON UPDATE NO ACTION
        `);
        await queryRunner.query(`
            ALTER TABLE \`booking\`
            ADD CONSTRAINT \`FK_9f755d011b9b8199461aaa06613\` FOREIGN KEY (\`aidServiceId\`) REFERENCES \`aid_service\`(\`id\`) ON DELETE NO ACTION ON UPDATE NO ACTION
        `);
        await queryRunner.query(`
            ALTER TABLE \`booking\`
            ADD CONSTRAINT \`FK_1dc4b236b764ed8d1552eff2434\` FOREIGN KEY (\`aidServiceProfileId\`) REFERENCES \`aid_service_profile\`(\`id\`) ON DELETE NO ACTION ON UPDATE NO ACTION
        `);
        await queryRunner.query(`
            ALTER TABLE \`booking\`
            ADD CONSTRAINT \`FK_e92ee85850420c227ec980ce76c\` FOREIGN KEY (\`profileId\`) REFERENCES \`profile\`(\`id\`) ON DELETE NO ACTION ON UPDATE NO ACTION
        `);
        await queryRunner.query(`
            ALTER TABLE \`profile\`
            ADD CONSTRAINT \`FK_d307cd0f00be8c8efcc831102b2\` FOREIGN KEY (\`walletId\`) REFERENCES \`profile_wallet\`(\`id\`) ON DELETE CASCADE ON UPDATE NO ACTION
        `);
        await queryRunner.query(`
            ALTER TABLE \`profile\`
            ADD CONSTRAINT \`FK_2e55eaf05dc6707d1541e7bebf9\` FOREIGN KEY (\`aidServiceProfileId\`) REFERENCES \`aid_service_profile\`(\`id\`) ON DELETE CASCADE ON UPDATE NO ACTION
        `);
        await queryRunner.query(`
            ALTER TABLE \`report\`
            ADD CONSTRAINT \`FK_72e61826547d60306404d4786ea\` FOREIGN KEY (\`profile_id\`) REFERENCES \`profile\`(\`id\`) ON DELETE NO ACTION ON UPDATE NO ACTION
        `);
        await queryRunner.query(`
            ALTER TABLE \`report\`
            ADD CONSTRAINT \`FK_e66c500f263ab1aaaf63f501d51\` FOREIGN KEY (\`entityOwnerId\`) REFERENCES \`profile\`(\`id\`) ON DELETE NO ACTION ON UPDATE NO ACTION
        `);
        await queryRunner.query(`
            ALTER TABLE \`report_comment\`
            ADD CONSTRAINT \`FK_3f3504bbd85a4bc8546ac4d1392\` FOREIGN KEY (\`profileId\`) REFERENCES \`profile\`(\`id\`) ON DELETE NO ACTION ON UPDATE NO ACTION
        `);
        await queryRunner.query(`
            ALTER TABLE \`report_comment\`
            ADD CONSTRAINT \`FK_78fb2f5b494cf91bc899f28ead7\` FOREIGN KEY (\`reportId\`) REFERENCES \`report\`(\`id\`) ON DELETE NO ACTION ON UPDATE NO ACTION
        `);
        await queryRunner.query(`
            ALTER TABLE \`notification\`
            ADD CONSTRAINT \`FK_dd9610f49f6281c705287cf8e67\` FOREIGN KEY (\`creatorId\`) REFERENCES \`profile\`(\`id\`) ON DELETE NO ACTION ON UPDATE NO ACTION
        `);
        await queryRunner.query(`
            ALTER TABLE \`notification\`
            ADD CONSTRAINT \`FK_758d70a0e61243171e785989070\` FOREIGN KEY (\`receiverId\`) REFERENCES \`profile\`(\`id\`) ON DELETE NO ACTION ON UPDATE NO ACTION
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE \`notification\` DROP FOREIGN KEY \`FK_758d70a0e61243171e785989070\`
        `);
        await queryRunner.query(`
            ALTER TABLE \`notification\` DROP FOREIGN KEY \`FK_dd9610f49f6281c705287cf8e67\`
        `);
        await queryRunner.query(`
            ALTER TABLE \`report_comment\` DROP FOREIGN KEY \`FK_78fb2f5b494cf91bc899f28ead7\`
        `);
        await queryRunner.query(`
            ALTER TABLE \`report_comment\` DROP FOREIGN KEY \`FK_3f3504bbd85a4bc8546ac4d1392\`
        `);
        await queryRunner.query(`
            ALTER TABLE \`report\` DROP FOREIGN KEY \`FK_e66c500f263ab1aaaf63f501d51\`
        `);
        await queryRunner.query(`
            ALTER TABLE \`report\` DROP FOREIGN KEY \`FK_72e61826547d60306404d4786ea\`
        `);
        await queryRunner.query(`
            ALTER TABLE \`profile\` DROP FOREIGN KEY \`FK_2e55eaf05dc6707d1541e7bebf9\`
        `);
        await queryRunner.query(`
            ALTER TABLE \`profile\` DROP FOREIGN KEY \`FK_d307cd0f00be8c8efcc831102b2\`
        `);
        await queryRunner.query(`
            ALTER TABLE \`booking\` DROP FOREIGN KEY \`FK_e92ee85850420c227ec980ce76c\`
        `);
        await queryRunner.query(`
            ALTER TABLE \`booking\` DROP FOREIGN KEY \`FK_1dc4b236b764ed8d1552eff2434\`
        `);
        await queryRunner.query(`
            ALTER TABLE \`booking\` DROP FOREIGN KEY \`FK_9f755d011b9b8199461aaa06613\`
        `);
        await queryRunner.query(`
            ALTER TABLE \`payment_transaction\` DROP FOREIGN KEY \`FK_e25ef1ea9f15b50d4aa150731a1\`
        `);
        await queryRunner.query(`
            ALTER TABLE \`payment_transaction\` DROP FOREIGN KEY \`FK_a0df4573f2a0c4d351fea2c5986\`
        `);
        await queryRunner.query(`
            ALTER TABLE \`aid_service\` DROP FOREIGN KEY \`FK_bf0c29f8bba419447fde8fbed43\`
        `);
        await queryRunner.query(`
            ALTER TABLE \`aid_service_cluster\` DROP FOREIGN KEY \`FK_bb1c821ee7b4c78c4ca909d657d\`
        `);
        await queryRunner.query(`
            ALTER TABLE \`aid_service_cluster\` DROP FOREIGN KEY \`FK_425b0a6f642f091a9a49975d8f0\`
        `);
        await queryRunner.query(`
            ALTER TABLE \`profile_cluster\` DROP FOREIGN KEY \`FK_b1e2c1cc3a940ed52b1ea664477\`
        `);
        await queryRunner.query(`
            ALTER TABLE \`profile_cluster\` DROP FOREIGN KEY \`FK_d97aad3ecb862bab0f395747f3c\`
        `);
        await queryRunner.query(`
            ALTER TABLE \`aid_service_tag\` DROP FOREIGN KEY \`FK_81a7eb4e5de9ec5fc0f0d548b37\`
        `);
        await queryRunner.query(`
            ALTER TABLE \`aid_service_tag\` DROP FOREIGN KEY \`FK_c8e96e96979cd2bf2afd75e91d2\`
        `);
        await queryRunner.query(`
            ALTER TABLE \`auth\` DROP FOREIGN KEY \`FK_ca49e738c1e64b0c839cae30d4e\`
        `);
        await queryRunner.query(`
            ALTER TABLE \`auth\` DROP FOREIGN KEY \`FK_b368cb67ee97687c9fdc9a04153\`
        `);
        await queryRunner.query(`
            DROP TABLE \`notification\`
        `);
        await queryRunner.query(`
            DROP TABLE \`report_comment\`
        `);
        await queryRunner.query(`
            DROP TABLE \`report\`
        `);
        await queryRunner.query(`
            DROP TABLE \`review_and_rating\`
        `);
        await queryRunner.query(`
            DROP TABLE \`profile_wallet\`
        `);
        await queryRunner.query(`
            DROP INDEX \`REL_2e55eaf05dc6707d1541e7bebf\` ON \`profile\`
        `);
        await queryRunner.query(`
            DROP INDEX \`REL_d307cd0f00be8c8efcc831102b\` ON \`profile\`
        `);
        await queryRunner.query(`
            DROP TABLE \`profile\`
        `);
        await queryRunner.query(`
            DROP TABLE \`booking\`
        `);
        await queryRunner.query(`
            DROP TABLE \`aid_service_profile\`
        `);
        await queryRunner.query(`
            DROP INDEX \`REL_a0df4573f2a0c4d351fea2c598\` ON \`payment_transaction\`
        `);
        await queryRunner.query(`
            DROP TABLE \`payment_transaction\`
        `);
        await queryRunner.query(`
            DROP TABLE \`aid_service\`
        `);
        await queryRunner.query(`
            DROP TABLE \`aid_service_cluster\`
        `);
        await queryRunner.query(`
            DROP TABLE \`cluster\`
        `);
        await queryRunner.query(`
            DROP TABLE \`profile_cluster\`
        `);
        await queryRunner.query(`
            DROP TABLE \`aid_service_tag\`
        `);
        await queryRunner.query(`
            DROP TABLE \`tag\`
        `);
        await queryRunner.query(`
            DROP INDEX \`REL_ca49e738c1e64b0c839cae30d4\` ON \`auth\`
        `);
        await queryRunner.query(`
            DROP INDEX \`IDX_373ead146f110f04dad6084815\` ON \`auth\`
        `);
        await queryRunner.query(`
            DROP TABLE \`auth\`
        `);
        await queryRunner.query(`
            DROP INDEX \`IDX_ae4578dcaed5adff96595e6166\` ON \`role\`
        `);
        await queryRunner.query(`
            DROP TABLE \`role\`
        `);
    }

}
